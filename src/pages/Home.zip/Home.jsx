import React from 'react'
import HomeSection1 from './../components/homeManual/HomeSection1';
import HomeSection2 from '../components/homeManual/HomeSection2';
import HomeSection3 from '../components/homeManual/HomeSection3';
import HomeSection4 from '../components/homeManual/HomeSection4';
import HomeSection5 from '../components/homeManual/HomeSection5';
import HomeSection6 from '../components/homeManual/HomeSection6';
import HomeSection7 from '../components/homeManual/HomeSection7';
import HomeSection8 from '../components/homeManual/HomeSection8';

const Home = () => {
  return (
    <div >
      <div  >
        <HomeSection1/>
      </div>
      <div >
        <HomeSection2/>
      </div>
      <div >
        <HomeSection3/>
      </div>
      <div>
        <HomeSection4/>
      </div>
      <div >
        <HomeSection5/>
      </div>
      <div >
        <HomeSection6/>
      </div>

      <div >
        <HomeSection7/>
      </div>

      <div>
        <HomeSection8/>
      </div>
    </div>
  )
}

export default Home
